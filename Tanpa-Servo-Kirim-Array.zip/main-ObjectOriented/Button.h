#ifndef BUTTON_H
#define BUTTON_H

#define BUTTON_PIN   6    // Define the pin for the pushbutton

class ButtonModule {
public:
  ButtonModule();
  bool isPressed();

private:
};

#endif
